export type SocialApp = 'tiktok' | 'reels' | 'shorts';

export type VideoCategory = 
  | 'brainrot_meme' 
  | 'gossip_drama' 
  | 'sensory_loop' 
  | 'ragebait' 
  | 'npc_stream' 
  | 'high_value_tech' 
  | 'educational';

export interface BrainRotVideo {
  id: string;
  app: SocialApp;
  title: string;
  creator: string;
  creatorAvatar: string;
  caption: string;
  soundName: string;
  likes: string;
  comments: string;
  shares: string;
  category: VideoCategory;
  brainRotScore: number; // 0 to 100 (100 = total zero-value brain rot)
  valueLabel: string;
  simulatedVisualType: 'slime_split' | 'npc_streamer' | 'celebrity_gossip' | 'dance_meme' | 'ragebait_prank' | 'python_tutorial' | 'system_design_clip';
  extractedOcr: string[];
  audioTranscript: string;
  dominantThemes: string[];
}

export type GoalTrack = 'leetcode' | 'english_vocab' | 'system_design' | 'finance' | 'mindfulness';

export interface GoalChallenge {
  id: string;
  track: GoalTrack;
  trackLabel: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  summary: string;
  microLesson: {
    title: string;
    keyPoints: string[];
    codeSnippet?: string;
    vocabData?: {
      word: string;
      pronunciation: string;
      partOfSpeech: string;
      definition: string;
      example: string;
      mnemonic: string;
    };
    architectureFlow?: {
      source: string;
      destination: string;
      protocol: string;
      note: string;
    }[];
  };
  quiz: {
    question: string;
    codeSnippet?: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface PermissionSettings {
  accessibilityService: boolean;
  systemAlertWindow: boolean; // Display over other apps
  usageStatsPermission: boolean;
  batteryOptimizationIgnored: boolean;
}

export interface AddictionSession {
  isActive: boolean;
  consecutiveZeroValueSeconds: number;
  totalZeroValueVideos: number;
  totalHighValueVideos: number;
  brainRotAccumulator: number; // 0 - 100
  thresholdSeconds: number; // default 900s (15 min) or adjustable
  isHijacked: boolean;
  interceptionsCount: number;
  quizzesSolvedCount: number;
  focusMinutesSaved: number;
}
