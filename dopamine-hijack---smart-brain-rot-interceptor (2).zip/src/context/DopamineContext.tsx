/**
 * @file src/context/DopamineContext.tsx
 * @description Central State Machine & Controller for the Dopamine Hijack SaaS System.
 * Coordinates background accessibility simulation, real-time screen extraction telemetry,
 * addiction accumulation counters, full-screen intercept overlays, and edge-case-safe navigation.
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  BrainRotVideo, 
  GoalChallenge, 
  GoalTrack, 
  PermissionSettings, 
  SocialApp 
} from '../types';
import { MOCK_VIDEOS } from '../data/mockVideos';
import { GOAL_CHALLENGES } from '../data/challenges';
import { sound } from '../utils/soundEffects';

interface DopamineContextType {
  // Feed & Navigation State
  currentVideo: BrainRotVideo;
  videoIndex: number;
  totalVideos: number;
  activeApp: SocialApp;
  setActiveApp: (app: SocialApp) => void;
  nextVideo: () => void;
  prevVideo: () => void;
  jumpToVideo: (idx: number) => void;

  // Real-time Screen Analysis Engine (Simulated Accessibility + OCR)
  isScanningScreen: boolean;
  activeOcrStream: string[];
  activeAudioTranscript: string;
  activeContentClassification: {
    category: string;
    brainRotScore: number;
    valueLabel: string;
  };

  // Addiction & Brain-Rot Telemetry
  consecutiveSeconds: number;
  thresholdSeconds: number;
  setThresholdSeconds: (sec: number) => void;
  brainRotLevel: number; // 0 to 100
  addictionStatus: 'SAFE' | 'MILD_FATIGUE' | 'HIGH_ADDICTION';
  totalZeroValueVideos: number;
  totalHighValueVideos: number;

  // The Interception (Full-Screen Hijack Overlay)
  isHijacked: boolean;
  currentChallenge: GoalChallenge;
  challengeProgressSec: number;
  isLessonCompleted: boolean;
  selectedOption: number | null;
  quizOutcome: 'idle' | 'correct' | 'wrong';
  quizAttempts: number;
  canDismiss: boolean;
  solveChallengeAndDismiss: (exitApp: boolean) => void;
  submitAnswer: (index: number) => void;
  triggerManualHijack: () => void;
  fastForwardAddiction: () => void;

  // Permissions Simulation
  permissions: PermissionSettings;
  togglePermission: (key: keyof PermissionSettings) => void;
  enableAllPermissions: () => void;
  showPermissionModal: boolean;
  setShowPermissionModal: (show: boolean) => void;

  // Configuration & Preferences
  selectedTracks: GoalTrack[];
  toggleTrack: (track: GoalTrack) => void;
  strictLockMode: boolean;
  setStrictLockMode: (val: boolean) => void;
  language: 'roman_urdu' | 'english';
  setLanguage: (lang: 'roman_urdu' | 'english') => void;

  // Historical Analytics & Gamification
  interceptionsCount: number;
  quizzesSolvedCount: number;
  minutesSaved: number;
  dopamineDetoxScore: number;
  resetAllStats: () => void;
}

const DopamineContext = createContext<DopamineContextType | undefined>(undefined);

// Safe fallback video in case the video array is uninitialized
const SAFE_BASELINE_FALLBACK_VIDEO: BrainRotVideo = {
  id: 'vid-fallback-default',
  app: 'tiktok',
  title: 'Mindful Tech Focus: Clean Algorithms',
  creator: '@system_architect',
  creatorAvatar: '👨‍💻',
  caption: 'Replace mindless scrolling with intentional high-value learning. #software #dsa #growth',
  soundName: 'Ambient Focus Frequency 432Hz',
  likes: '100K',
  comments: '1.2K',
  shares: '5K',
  category: 'high_value_tech',
  brainRotScore: 10,
  valueLabel: 'High Value (Educational STEM)',
  simulatedVisualType: 'python_tutorial',
  extractedOcr: ['# High Value Focus Mode', 'O(1) Memory Overhead', 'Zero Brain Rot'],
  audioTranscript: 'Redirecting neural attention from passive consumption to active skill building.',
  dominantThemes: ['Clean Architecture', 'Deep Work', 'Cognitive Discipline']
};

export const DopamineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [videoIndex, setVideoIndex] = useState(0);
  const [activeApp, setActiveApp] = useState<SocialApp>('tiktok');
  const [isScanningScreen, setIsScanningScreen] = useState(true);

  // System permissions state (Accessibility Service + Window Overlay)
  const [permissions, setPermissions] = useState<PermissionSettings>({
    accessibilityService: true,
    systemAlertWindow: true,
    usageStatsPermission: true,
    batteryOptimizationIgnored: true,
  });
  const [showPermissionModal, setShowPermissionModal] = useState(false);

  // Goal Preferences & Learning Tracks
  const [selectedTracks, setSelectedTracks] = useState<GoalTrack[]>([
    'leetcode',
    'english_vocab',
    'system_design',
    'mindfulness'
  ]);
  const [strictLockMode, setStrictLockMode] = useState(true);
  const [language, setLanguage] = useState<'roman_urdu' | 'english'>('roman_urdu');

  // Addiction counter & Brain-Rot tracking
  // Default threshold: 15s for instant snappy demonstration, with UI switcher for real 15min (900s)
  const [thresholdSeconds, setThresholdSeconds] = useState(15);
  const [consecutiveSeconds, setConsecutiveSeconds] = useState(0);
  const [brainRotLevel, setBrainRotLevel] = useState(15);
  const [totalZeroValueVideos, setTotalZeroValueVideos] = useState(1);
  const [totalHighValueVideos, setTotalHighValueVideos] = useState(0);

  // Interception & Quiz State
  const [isHijacked, setIsHijacked] = useState(false);
  const [currentChallenge, setCurrentChallenge] = useState<GoalChallenge>(GOAL_CHALLENGES[0]);
  const [challengeProgressSec, setChallengeProgressSec] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizOutcome, setQuizOutcome] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [quizAttempts, setQuizAttempts] = useState(0);

  // Analytics
  const [interceptionsCount, setInterceptionsCount] = useState(0);
  const [quizzesSolvedCount, setQuizzesSolvedCount] = useState(0);
  const [minutesSaved, setMinutesSaved] = useState(0);
  const [dopamineDetoxScore, setDopamineDetoxScore] = useState(120);

  // Defensive index resolution: Guarantee an invariant non-null video object
  const currentVideo: BrainRotVideo = 
    MOCK_VIDEOS.length > 0
      ? (MOCK_VIDEOS[videoIndex] || MOCK_VIDEOS[0] || SAFE_BASELINE_FALLBACK_VIDEO)
      : SAFE_BASELINE_FALLBACK_VIDEO;

  const highAddictionTriggeredRef = useRef(false);

  /**
   * Filter and select a random micro-learning challenge matching active goal tracks.
   */
  const getRandomChallenge = useCallback((): GoalChallenge => {
    const available = GOAL_CHALLENGES.filter(c => selectedTracks.includes(c.track));
    const pool = available.length > 0 ? available : GOAL_CHALLENGES;
    const randomIndex = Math.floor(Math.random() * pool.length);
    return pool[randomIndex] || GOAL_CHALLENGES[0];
  }, [selectedTracks]);

  /**
   * Triggers the Full-Screen Custom Overlay Hijack over the active social media feed.
   */
  const triggerHijack = useCallback((reasonChallenge?: GoalChallenge) => {
    // Only proceed if overlay and accessibility permissions are active
    if (!permissions.systemAlertWindow || !permissions.accessibilityService) {
      setShowPermissionModal(true);
      return;
    }

    const nextChallenge = reasonChallenge || getRandomChallenge();
    setCurrentChallenge(nextChallenge);
    setIsHijacked(true);
    setChallengeProgressSec(0);
    setSelectedOption(null);
    setQuizOutcome('idle');
    setQuizAttempts(0);
    setInterceptionsCount(prev => prev + 1);

    // Audio notification cue
    sound.playInterceptAlert();
  }, [permissions.accessibilityService, permissions.systemAlertWindow, getRandomChallenge]);

  /**
   * Main addiction accumulation timer loop.
   * Simulates background accessibility node analysis and calculates brain-rot progress.
   */
  useEffect(() => {
    if (isHijacked) return;

    const timer = setInterval(() => {
      setIsScanningScreen(true);
      const isZeroValue = currentVideo.brainRotScore > 60;

      if (isZeroValue) {
        setConsecutiveSeconds(prev => {
          const nextSec = prev + 1;
          const ratio = Math.min(nextSec / Math.max(thresholdSeconds, 1), 1);
          const computedRot = Math.round(30 + ratio * 65);
          setBrainRotLevel(computedRot);

          // Trigger High Addiction threshold intercept
          if (nextSec >= thresholdSeconds && !highAddictionTriggeredRef.current) {
            highAddictionTriggeredRef.current = true;
            setTimeout(() => {
              triggerHijack();
            }, 400);
          }
          return nextSec;
        });
      } else {
        // High-value educational content cools down brain-rot
        setConsecutiveSeconds(prev => Math.max(0, prev - 2));
        setBrainRotLevel(prev => Math.max(10, prev - 3));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [isHijacked, currentVideo, thresholdSeconds, triggerHijack]);

  /**
   * 30-second micro-lesson progress timer while intercepted.
   */
  useEffect(() => {
    if (!isHijacked) return;

    const lessonTimer = setInterval(() => {
      setChallengeProgressSec(prev => (prev < 30 ? prev + 1 : 30));
    }, 1000);

    return () => clearInterval(lessonTimer);
  }, [isHijacked]);

  /**
   * User navigation: Advance to next video in the feed.
   * Resumes Web Audio Context on explicit user gesture to satisfy browser Autoplay Policy.
   */
  const nextVideo = useCallback(() => {
    if (isHijacked) return;

    // Client user action: ensure AudioContext is primed
    sound.ensureAudioReady();

    if (consecutiveSeconds >= thresholdSeconds) {
      triggerHijack();
      return;
    }

    if (MOCK_VIDEOS.length === 0) return;

    const nextIdx = (videoIndex + 1) % MOCK_VIDEOS.length;
    setVideoIndex(nextIdx);

    const nextVid = MOCK_VIDEOS[nextIdx];
    if (nextVid && nextVid.brainRotScore > 60) {
      setTotalZeroValueVideos(prev => prev + 1);
    } else {
      setTotalHighValueVideos(prev => prev + 1);
    }
  }, [isHijacked, consecutiveSeconds, thresholdSeconds, videoIndex, triggerHijack]);

  /**
   * User navigation: Return to previous video in the feed.
   */
  const prevVideo = useCallback(() => {
    if (isHijacked) return;

    // Client user action: ensure AudioContext is primed
    sound.ensureAudioReady();

    if (MOCK_VIDEOS.length === 0) return;

    const prevIdx = videoIndex === 0 ? MOCK_VIDEOS.length - 1 : videoIndex - 1;
    setVideoIndex(prevIdx);
  }, [isHijacked, videoIndex]);

  /**
   * User navigation: Jump directly to a specific video index with safety bounds.
   */
  const jumpToVideo = useCallback((idx: number) => {
    if (isHijacked) return;
    sound.ensureAudioReady();

    if (MOCK_VIDEOS.length === 0) return;
    const safeIdx = Math.max(0, Math.min(idx, MOCK_VIDEOS.length - 1));
    setVideoIndex(safeIdx);
  }, [isHijacked]);

  /**
   * Evaluates user quiz submission and updates reward telemetry.
   */
  const submitAnswer = useCallback((index: number) => {
    // Explicit user action: ensure AudioContext is primed
    sound.ensureAudioReady();

    setSelectedOption(index);
    setQuizAttempts(prev => prev + 1);

    if (index === currentChallenge.quiz.correctIndex) {
      setQuizOutcome('correct');
      sound.playSuccessFanfare();
      confetti({
        particleCount: 85,
        spread: 60,
        origin: { y: 0.6 }
      });
      setQuizzesSolvedCount(prev => prev + 1);
      setMinutesSaved(prev => prev + 15);
      setDopamineDetoxScore(prev => prev + 45);
    } else {
      setQuizOutcome('wrong');
      sound.playIncorrectBuzz();
    }
  }, [currentChallenge]);

  /**
   * Dismisses the interceptor overlay after successful micro-learning challenge completion.
   * 
   * STRUCTURAL FIX: When the user exits the intercepted social app to engage deep focus mode,
   * an explicit index verification check is executed on MOCK_VIDEOS. If the search for a
   * 'high_value_tech' category video yields an index out of bounds (-1), it elegantly falls back
   * to the safe baseline standard index (0) instead of throwing an out-of-bounds array state exception.
   */
  const solveChallengeAndDismiss = useCallback((exitApp: boolean) => {
    sound.ensureAudioReady();

    setIsHijacked(false);
    setConsecutiveSeconds(0);
    setBrainRotLevel(15);
    highAddictionTriggeredRef.current = false;

    if (exitApp) {
      // User chose to exit TikTok / social media app and enter deep focus mode
      setMinutesSaved(prev => prev + 30);
      setDopamineDetoxScore(prev => prev + 80);

      // Robust index verification check on MOCK_VIDEOS:
      const targetCategoryIndex = MOCK_VIDEOS.findIndex(v => v.category === 'high_value_tech');
      const safeIndex = (targetCategoryIndex >= 0 && targetCategoryIndex < MOCK_VIDEOS.length)
        ? targetCategoryIndex
        : 0; // Safe baseline standard index fallback

      setVideoIndex(safeIndex);
    } else {
      // User continues scrolling: advance to next video with circular bounds safety
      const safeNextIdx = (MOCK_VIDEOS.length > 0)
        ? (videoIndex + 1) % MOCK_VIDEOS.length
        : 0;
      setVideoIndex(safeNextIdx);
    }
  }, [videoIndex]);

  /**
   * Developer / Demo utility to fast-forward addiction to 15m threshold.
   */
  const fastForwardAddiction = useCallback(() => {
    sound.ensureAudioReady();
    setConsecutiveSeconds(thresholdSeconds);
    setBrainRotLevel(98);
    highAddictionTriggeredRef.current = true;
    triggerHijack();
  }, [thresholdSeconds, triggerHijack]);

  const triggerManualHijack = useCallback(() => {
    sound.ensureAudioReady();
    triggerHijack();
  }, [triggerHijack]);

  const togglePermission = useCallback((key: keyof PermissionSettings) => {
    setPermissions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  }, []);

  const enableAllPermissions = useCallback(() => {
    setPermissions({
      accessibilityService: true,
      systemAlertWindow: true,
      usageStatsPermission: true,
      batteryOptimizationIgnored: true
    });
    setShowPermissionModal(false);
  }, []);

  const toggleTrack = useCallback((track: GoalTrack) => {
    setSelectedTracks(prev => {
      if (prev.includes(track)) {
        if (prev.length <= 1) return prev; // Keep at least one track
        return prev.filter(t => t !== track);
      } else {
        return [...prev, track];
      }
    });
  }, []);

  const resetAllStats = useCallback(() => {
    setInterceptionsCount(0);
    setQuizzesSolvedCount(0);
    setMinutesSaved(0);
    setDopamineDetoxScore(50);
    setConsecutiveSeconds(0);
    setBrainRotLevel(15);
    highAddictionTriggeredRef.current = false;
  }, []);

  // Compute status tiers based on brain-rot saturation
  const addictionStatus: 'SAFE' | 'MILD_FATIGUE' | 'HIGH_ADDICTION' = 
    brainRotLevel > 75 ? 'HIGH_ADDICTION' :
    brainRotLevel > 45 ? 'MILD_FATIGUE' : 'SAFE';

  const isLessonCompleted = challengeProgressSec >= 30;
  const canDismiss = strictLockMode ? quizOutcome === 'correct' : (isLessonCompleted || quizOutcome === 'correct');

  return (
    <DopamineContext.Provider
      value={{
        currentVideo,
        videoIndex,
        totalVideos: MOCK_VIDEOS.length,
        activeApp,
        setActiveApp,
        nextVideo,
        prevVideo,
        jumpToVideo,

        isScanningScreen,
        activeOcrStream: currentVideo.extractedOcr,
        activeAudioTranscript: currentVideo.audioTranscript,
        activeContentClassification: {
          category: currentVideo.category,
          brainRotScore: currentVideo.brainRotScore,
          valueLabel: currentVideo.valueLabel,
        },

        consecutiveSeconds,
        thresholdSeconds,
        setThresholdSeconds,
        brainRotLevel,
        addictionStatus,
        totalZeroValueVideos,
        totalHighValueVideos,

        isHijacked,
        currentChallenge,
        challengeProgressSec,
        isLessonCompleted,
        selectedOption,
        quizOutcome,
        quizAttempts,
        canDismiss,
        solveChallengeAndDismiss,
        submitAnswer,
        triggerManualHijack,
        fastForwardAddiction,

        permissions,
        togglePermission,
        enableAllPermissions,
        showPermissionModal,
        setShowPermissionModal,

        selectedTracks,
        toggleTrack,
        strictLockMode,
        setStrictLockMode,
        language,
        setLanguage,

        interceptionsCount,
        quizzesSolvedCount,
        minutesSaved,
        dopamineDetoxScore,
        resetAllStats,
      }}
    >
      {children}
    </DopamineContext.Provider>
  );
};

export const useDopamine = () => {
  const context = useContext(DopamineContext);
  if (!context) {
    throw new Error('useDopamine must be used within a DopamineProvider');
  }
  return context;
};
