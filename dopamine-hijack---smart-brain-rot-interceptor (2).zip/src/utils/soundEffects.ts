/**
 * @file src/utils/soundEffects.ts
 * @description Production-grade Web Audio API sound synthesizer and Autoplay Policy compliance engine.
 * Generates synthetic acoustic cues (intercept alerts, success fanfares, buzzer tones) with zero external assets.
 * Implements strict AudioContext state management protocols to guarantee zero browser autoplay console warnings.
 */

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isUnlocked: boolean = false;
  private unlockPromise: Promise<boolean> | null = null;

  constructor() {
    // Automatically bind non-intrusive one-time gesture listeners on client initialization
    if (typeof window !== 'undefined') {
      const unlockHandler = () => {
        this.resumeAudioContext().catch(() => {});
        window.removeEventListener('pointerdown', unlockHandler);
        window.removeEventListener('keydown', unlockHandler);
        window.removeEventListener('touchstart', unlockHandler);
      };

      window.addEventListener('pointerdown', unlockHandler, { once: true, passive: true });
      window.addEventListener('keydown', unlockHandler, { once: true, passive: true });
      window.addEventListener('touchstart', unlockHandler, { once: true, passive: true });
    }
  }

  /**
   * Lazily initializes and caches the singleton AudioContext instance.
   * Handles webkit prefixed constructors for legacy Safari compatibility.
   */
  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.ctx) {
      const AudioContextClass = 
        window.AudioContext || 
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

      if (AudioContextClass) {
        try {
          this.ctx = new AudioContextClass();
        } catch {
          // Graceful fallback if audio hardware is disabled/restricted
          this.ctx = null;
        }
      }
    }

    return this.ctx;
  }

  /**
   * Explicit client-action wrapper to resume suspended AudioContext instances.
   * Modern browsers (Chrome 66+, Safari 11+, Firefox) require an explicit user gesture
   * before permitting sound playback. Call this method on explicit user interactions
   * (e.g., Swipe Down, Next Video, Quiz Option clicks) to preemptively bypass Autoplay blocks.
   *
   * @returns Promise<boolean> True if AudioContext is running and ready for audio dispatch
   */
  public async resumeAudioContext(): Promise<boolean> {
    const ctx = this.getContext();
    if (!ctx) return false;

    if (ctx.state === 'running') {
      this.isUnlocked = true;
      return true;
    }

    if (ctx.state === 'suspended') {
      // Re-use active in-flight unlock promise if multiple calls occur simultaneously
      if (!this.unlockPromise) {
        this.unlockPromise = ctx.resume()
          .then(() => {
            this.isUnlocked = ctx.state === 'running';
            return this.isUnlocked;
          })
          .catch(() => {
            return false;
          })
          .finally(() => {
            this.unlockPromise = null;
          });
      }
      return this.unlockPromise;
    }

    return false;
  }

  /**
   * Synchronous check or trigger to ensure audio capability is unlocked.
   */
  public ensureAudioReady(): void {
    void this.resumeAudioContext();
  }

  /**
   * Dispatches the High-Addiction Dopamine Interception siren alert.
   * Synthesizes a piercing dual-tone frequency shift followed by a sub-harmonic drop.
   */
  public playInterceptAlert(): void {
    void this.resumeAudioContext().then(() => {
      try {
        const ctx = this.getContext();
        if (!ctx || ctx.state !== 'running') return;
        const now = ctx.currentTime;

        // Primary frequency glide: D5 (587.33Hz) -> A5 (880Hz)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'triangle';
        osc1.frequency.setValueAtTime(587.33, now);
        osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12);

        gain1.gain.setValueAtTime(0.2, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.35);

        // Sub-harmonic drop: 160Hz -> 60Hz
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(160, now + 0.05);
        osc2.frequency.exponentialRampToValueAtTime(60, now + 0.4);

        gain2.gain.setValueAtTime(0.25, now + 0.05);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.05);
        osc2.stop(now + 0.45);
      } catch {
        // Fallback silently if device audio output is unavailable
      }
    });
  }

  /**
   * Dispatches the 4-note ascending major arpeggio victory fanfare
   * when a user correctly solves a LeetCode or vocabulary challenge.
   */
  public playSuccessFanfare(): void {
    void this.resumeAudioContext().then(() => {
      try {
        const ctx = this.getContext();
        if (!ctx || ctx.state !== 'running') return;
        const now = ctx.currentTime;
        // Ascending C Major chord notes: C5 (523.25Hz), E5 (659.25Hz), G5 (783.99Hz), C6 (1046.50Hz)
        const notes = [523.25, 659.25, 783.99, 1046.50];

        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const noteStart = now + idx * 0.09;

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, noteStart);

          gain.gain.setValueAtTime(0, noteStart);
          gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.4);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(noteStart);
          osc.stop(noteStart + 0.45);
        });
      } catch {
        // Fallback silently
      }
    });
  }

  /**
   * Dispatches a gentle dissonance buzz on incorrect quiz submission.
   */
  public playIncorrectBuzz(): void {
    void this.resumeAudioContext().then(() => {
      try {
        const ctx = this.getContext();
        if (!ctx || ctx.state !== 'running') return;
        const now = ctx.currentTime;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.setValueAtTime(110, now + 0.12);

        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      } catch {
        // Fallback silently
      }
    });
  }

  /**
   * Pronounces academic vocabulary words using the standard Web Speech API.
   *
   * @param word Target English word to articulate
   */
  public speakWord(word: string): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.rate = 0.85;
      utterance.pitch = 1.0;
      utterance.lang = 'en-US';
      window.speechSynthesis.speak(utterance);
    }
  }
}

export const sound = new SoundSynthesizer();
