import React from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Brain, 
  Languages, 
  HelpCircle,
  Smartphone,
  Flame,
  Zap
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';

interface HeaderProps {
  onOpenArchitecture: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenArchitecture }) => {
  const { 
    permissions, 
    setShowPermissionModal, 
    language, 
    setLanguage,
    addictionStatus,
    brainRotLevel 
  } = useDopamine();

  const isRomanUrdu = language === 'roman_urdu';
  const allPermissionsOk = permissions.accessibilityService && permissions.systemAlertWindow;

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Brand / Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-tight">
                Dopamine Hijack
              </h1>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-indigo-400 font-medium">Smart Interceptor</span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              {isRomanUrdu 
                ? 'Social media apps ko block kiye baghair brain-rot ko real-life goals mein tabdeel karein' 
                : 'Subconscious doomscroll circuit breaker powered by accessibility service & overlay'}
            </p>
          </div>
        </div>

        {/* Right Action Bar */}
        <div className="flex items-center gap-2.5">
          {/* Status Indicator */}
          <div className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-mono ${
            addictionStatus === 'HIGH_ADDICTION'
              ? 'bg-red-950/50 border-red-500/40 text-red-300'
              : 'bg-slate-900 border-slate-800 text-slate-300'
          }`}>
            <span>{isRomanUrdu ? 'Brain-Rot:' : 'Rot Index:'} {brainRotLevel}%</span>
          </div>

          {/* Permissions Modal Trigger */}
          <button
            onClick={() => setShowPermissionModal(true)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-colors ${
              allPermissionsOk
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/50'
                : 'bg-amber-950/40 border-amber-500/40 text-amber-300 hover:bg-amber-900/50'
            }`}
          >
            {allPermissionsOk ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span>
              {isRomanUrdu ? 'System Permissions' : 'Permissions Setup'}
            </span>
          </button>

          {/* Core Logic Explainer Trigger */}
          <button
            onClick={onOpenArchitecture}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-medium text-slate-300 flex items-center gap-1.5 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">
              {isRomanUrdu ? 'Yeh Kaam Kaise Karega?' : 'How It Works'}
            </span>
          </button>

          {/* Language Toggle */}
          <div className="flex items-center rounded-lg bg-slate-900 border border-slate-800 p-0.5 text-xs">
            <button
              onClick={() => setLanguage('roman_urdu')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                language === 'roman_urdu'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Roman Urdu
            </button>
            <button
              onClick={() => setLanguage('english')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                language === 'english'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              English
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
