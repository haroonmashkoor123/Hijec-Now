import React from 'react';
import { 
  ShieldCheck, 
  Layers, 
  Eye, 
  BatteryCharging, 
  Check, 
  X, 
  ExternalLink,
  Info
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';

export const PermissionsModal: React.FC = () => {
  const { 
    permissions, 
    togglePermission, 
    enableAllPermissions, 
    showPermissionModal, 
    setShowPermissionModal,
    language 
  } = useDopamine();

  if (!showPermissionModal) return null;

  const isRomanUrdu = language === 'roman_urdu';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl text-white space-y-5">
        
        {/* Modal Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isRomanUrdu ? 'System Permissions (Android / iOS)' : 'System Permissions Setup'}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {isRomanUrdu 
                  ? 'Smart Hijacking aur background screen reading ke liye zaroori permissions'
                  : 'Required privileges for background screen analysis & full-screen overlay'}
              </p>
            </div>
          </div>
          <button 
            onClick={() => setShowPermissionModal(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Why this is required explanation card */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 flex items-start gap-3">
          <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            {isRomanUrdu ? (
              <span>
                <strong>Dopamine Interceptor app ko block nahi karegi</strong>. Yeh Android Accessibility Service ke zariye TikTok/Reels ke captions aur audio read karti hai, aur 15 minute baad system overlay launch karti hai.
              </span>
            ) : (
              <span>
                <strong>This app never blocks or terminates your apps</strong>. It operates in the background via Android Accessibility & Display Over Apps (WindowManager) to detect zero-value doomscrolling and paint the micro-learning overlay.
              </span>
            )}
          </div>
        </div>

        {/* Permissions Switcher List */}
        <div className="space-y-3">
          {/* Permission 1: Accessibility Service */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 mt-0.5">
                <Eye className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  {isRomanUrdu ? '1. Accessibility Service Permission' : '1. Accessibility Service'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {isRomanUrdu 
                    ? 'TikTok aur Instagram Reels ke captions, subtitles aur view hierarchy read karne ke liye.' 
                    : 'Inspects on-screen captions, subtitles & view nodes in TikTok/Reels.'}
                </div>
              </div>
            </div>

            <button
              onClick={() => togglePermission('accessibilityService')}
              className={`w-11 h-6 rounded-full transition-colors relative flex items-center px-0.5 ${
                permissions.accessibilityService ? 'bg-indigo-600' : 'bg-slate-700'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                permissions.accessibilityService ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* Permission 2: Display Over Other Apps */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 mt-0.5">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  {isRomanUrdu ? '2. Display Over Other Apps (Overlay)' : '2. Display Over Other Apps'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {isRomanUrdu 
                    ? '15 min hone par TikTok ke upar 30s LeetCode/English video overlay lane ke liye.' 
                    : 'Permits drawing the 30s micro-learning challenge modal over active apps.'}
                </div>
              </div>
            </div>

            <button
              onClick={() => togglePermission('systemAlertWindow')}
              className={`w-11 h-6 rounded-full transition-colors relative flex items-center px-0.5 ${
                permissions.systemAlertWindow ? 'bg-indigo-600' : 'bg-slate-700'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                permissions.systemAlertWindow ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* Permission 3: Battery Optimization Ignore */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 mt-0.5">
                <BatteryCharging className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  {isRomanUrdu ? '3. Battery Optimization Bypass' : '3. Battery Optimization Exemption'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {isRomanUrdu 
                    ? 'Background classifier model ko active rakhne ke liye takay OS isay kill na kare.' 
                    : 'Prevents Android OS from killing the lightweight analyzer service.'}
                </div>
              </div>
            </div>

            <button
              onClick={() => togglePermission('batteryOptimizationIgnored')}
              className={`w-11 h-6 rounded-full transition-colors relative flex items-center px-0.5 ${
                permissions.batteryOptimizationIgnored ? 'bg-indigo-600' : 'bg-slate-700'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                permissions.batteryOptimizationIgnored ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </button>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="pt-2 flex items-center justify-end gap-2.5">
          <button
            onClick={() => setShowPermissionModal(false)}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
          >
            {isRomanUrdu ? 'Band Karein' : 'Close'}
          </button>
          <button
            onClick={enableAllPermissions}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Check className="w-4 h-4" />
            <span>{isRomanUrdu ? 'Sab Permissions Manzoor Karein' : 'Grant All Permissions'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
