import React from 'react';
import { 
  X, 
  Smartphone, 
  Scan, 
  Brain, 
  ShieldAlert, 
  CheckCircle2, 
  XCircle,
  Lightbulb,
  ArrowRight
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';

interface ArchitectureExplainerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureExplainerModal: React.FC<ArchitectureExplainerModalProps> = ({ isOpen, onClose }) => {
  const { language } = useDopamine();
  if (!isOpen) return null;

  const isRomanUrdu = language === 'roman_urdu';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl text-white space-y-6 my-8">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono text-indigo-400 font-bold uppercase tracking-wider">
              {isRomanUrdu ? 'Falsafa aur Technical Architecture' : 'Behavioral & Technical Architecture'}
            </div>
            <h2 className="text-lg font-bold text-white mt-1">
              {isRomanUrdu ? '🧠 Yeh Kaam Kaise Karega? (Core Logic)' : '🧠 Core Logic: How Dopamine Hijack Works'}
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Why Blocking Fails vs Why Hijack Works */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-red-950/30 border border-red-500/20 space-y-2">
            <div className="flex items-center gap-2 font-bold text-red-300">
              <XCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{isRomanUrdu ? 'Aam Blocking Apps Kyun Fail Hoti Hain?' : 'Why Naive Blocker Apps Fail:'}</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {isRomanUrdu 
                ? 'Jab koi app TikTok ya Instagram ko poori tarah block karti hai, to user irritated ho kar us app ko uninstall/delete kar deta hai. Insan ka dimagh pabandi se baghawat karta hai.' 
                : 'Standard app-blockers forcefully close apps. This creates irritation and withdrawal backlash, leading 94% of users to uninstall the blocker within 7 days.'}
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/20 space-y-2">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isRomanUrdu ? 'Dopamine Interruption Ka Formula:' : 'Dopamine Interception Strategy:'}</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {isRomanUrdu 
                ? 'App ko block nahi karte, balkay mindless dopamine loop ke beech mein 30s ki high-value informative video aur quiz le aate hain. Dimagh ko naya aur mufeed dopamine milta hai!' 
                : 'Do not terminate the app. Instead, intercept the subconscious scroll trance with high-stimulus micro-learning (LeetCode / Vocab) that satisfies the brain’s hunger with real cognitive value.'}
            </p>
          </div>
        </div>

        {/* The 4 Core Stages in Detail */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
            {isRomanUrdu ? '4 Bunyadi Marhalay (Detailed Flow):' : 'The 4 Core Architectural Steps:'}
          </h3>

          <div className="space-y-2.5 text-xs">
            {/* 1 */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sky-400 flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  <span>1. Accessibility Service & Overlay Permission (Android/iOS)</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">SYSTEM_ALERT_WINDOW</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isRomanUrdu 
                  ? 'Mobile app user se Accessibility Service aur Display Over Apps ki permission mangti hai. Is se app active TikTok/Reels ke UI window nodes, text views aur subtitles ko background mein monitor kar sakti hai bina kisi root access ke.' 
                  : 'The mobile app requests Android AccessibilityService + SYSTEM_ALERT_WINDOW privileges. This allows inspecting on-screen UI node hierarchies and drawing system overlays directly over running apps without root.'}
              </p>
            </div>

            {/* 2 */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-cyan-400 flex items-center gap-2">
                  <Scan className="w-4 h-4" />
                  <span>2. Real-Time Screen Video Extraction</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">ON-DEVICE OCR + NLP</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isRomanUrdu 
                  ? 'Jab user scroll karta hai, to screen par chalne wali video ke text, captions, hashtags aur audio stream ko background mein light-weight on-device AI model extract karta hai.' 
                  : 'On every vertical scroll event, the background service extracts on-screen text, subtitles, and audio snippets. A lightweight on-device classifier scores the cognitive value of the content.'}
              </p>
            </div>

            {/* 3 */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400 flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  <span>3. Brain-Rot Level Score & 15-Minute Counter</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">DOPAMINE SATURATION INDEX</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isRomanUrdu 
                  ? 'Agar user lagatar 15 minute se zero-value content (gossip, random dance, funny videos) dekh raha hai, to system ka counter "High Addiction" flag trigger kar deta hai.' 
                  : 'If the user consumes consecutive zero-value content (pranks, sensory soap loops, gossip podcasts) for 15 minutes, the counter flags a "High Addiction" state, queuing the next scroll for interception.'}
              </p>
            </div>

            {/* 4 */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-red-400 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4" />
                  <span>4. The Interception (Full-Screen Smart Hijack)</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">HARD INTERCEPT LOCK</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isRomanUrdu 
                  ? 'Agli video scroll hote hi, TikTok ke upar aik Full-Screen Custom Overlay UI aa jata hai jo user ke goals (Coding tutorials, LeetCode, English vocabulary) ki 30s interactive video chala deta hai. User tab tak aage nahi ja sakta jab tak quiz hal na kar le.' 
                  : 'As soon as the user tries to scroll to the next video, the full-screen overlay mounts. It presents a 30-second high-value micro-lesson and an interactive quiz. The screen remains locked until the user correctly solves the challenge.'}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            {isRomanUrdu ? 'Samajh Aa Gaya (Band Karein)' : 'Got It, Let’s Try It'}
          </button>
        </div>
      </div>
    </div>
  );
};
