import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Music, 
  Search, 
  Sparkles, 
  ChevronUp, 
  ChevronDown, 
  Eye, 
  EyeOff, 
  Scan, 
  Volume2, 
  AlertTriangle,
  Play,
  RotateCcw
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';
import { InterceptorOverlayUI } from './InterceptorOverlayUI';
import { sound } from '../utils/soundEffects';

export const PhoneSimulator: React.FC = () => {
  const { 
    currentVideo, 
    videoIndex, 
    totalVideos, 
    nextVideo, 
    prevVideo, 
    activeApp, 
    setActiveApp, 
    isHijacked,
    consecutiveSeconds,
    thresholdSeconds,
    brainRotLevel,
    addictionStatus,
    activeOcrStream,
    activeAudioTranscript,
    language,
    triggerManualHijack
  } = useDopamine();

  const [showScannerHud, setShowScannerHud] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCountDelta, setLikeCountDelta] = useState(0);

  const isRomanUrdu = language === 'roman_urdu';

  // Toggle like
  const handleLike = () => {
    sound.ensureAudioReady();
    setIsLiked(!isLiked);
    setLikeCountDelta(prev => (isLiked ? prev - 1 : prev + 1));
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Render simulated video animation background
  const renderSimulatedVideoGraphic = () => {
    const { simulatedVisualType } = currentVideo;

    switch (simulatedVisualType) {
      case 'dance_meme':
        return (
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-950 via-slate-900 to-purple-950 flex flex-col items-center justify-center p-4 select-none">
            <div className="relative">
              <div className="text-7xl animate-bounce duration-500 mb-2">🐱</div>
              <div className="absolute -bottom-2 -right-4 px-2 py-0.5 bg-red-600 rounded-full text-[10px] font-bold text-white shadow animate-pulse">
                VIRAL
              </div>
            </div>
            <div className="mt-4 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-sm border border-white/10 text-center max-w-[200px]">
              <div className="text-xs font-bold text-amber-300">POV: 3:00 AM Cat Thoughts</div>
              <div className="text-[10px] text-slate-300 mt-0.5">Brain-Rot Score: 92%</div>
            </div>
            {/* Pulsing sound waves */}
            <div className="flex items-center gap-1 mt-6">
              {[40, 70, 30, 90, 50, 80, 45].map((h, i) => (
                <div 
                  key={i} 
                  className="w-1 bg-pink-500/80 rounded-full animate-pulse" 
                  style={{ height: `${h * 0.4}px`, animationDelay: `${i * 120}ms` }} 
                />
              ))}
            </div>
          </div>
        );

      case 'slime_split':
        return (
          <div className="absolute inset-0 flex flex-col select-none">
            {/* Top Half: Subway Surfer style simulator */}
            <div className="flex-1 bg-gradient-to-b from-sky-900 to-indigo-950 flex items-center justify-center relative border-b border-white/10 overflow-hidden">
              <div className="text-xs font-mono text-cyan-300/80 absolute top-2 left-2 bg-black/40 px-2 py-0.5 rounded">
                SUBWAY SPEED RUN 4K
              </div>
              <div className="flex flex-col items-center animate-pulse">
                <span className="text-5xl">🛹</span>
                <span className="text-[10px] text-cyan-200 mt-1 font-mono">Endless Dopamine Loop</span>
              </div>
            </div>
            {/* Bottom Half: ASMR Soap Slicing simulator */}
            <div className="flex-1 bg-gradient-to-b from-purple-950 to-pink-950 flex items-center justify-center relative overflow-hidden">
              <div className="text-xs font-mono text-pink-300/80 absolute top-2 left-2 bg-black/40 px-2 py-0.5 rounded">
                ODDLY SATISFYING ASMR
              </div>
              <div className="flex flex-col items-center">
                <span className="text-5xl animate-bounce duration-700">🧼</span>
                <span className="text-[10px] text-pink-200 mt-1 font-mono">Soap Crunching Audio</span>
              </div>
            </div>
          </div>
        );

      case 'celebrity_gossip':
        return (
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-zinc-900 to-amber-950 flex flex-col items-center justify-center p-4 select-none">
            <div className="p-3 rounded-full bg-amber-500/10 border border-amber-500/20 mb-3">
              <span className="text-6xl">🎙️</span>
            </div>
            <div className="text-center px-4 py-2 bg-black/60 rounded-xl border border-white/10 backdrop-blur-sm max-w-[220px]">
              <div className="text-xs font-bold text-amber-400">UNFILTERED DRAMA PODCAST</div>
              <div className="text-[10px] text-slate-300 mt-1 italic">&ldquo;Did you see what they leaked?&rdquo;</div>
            </div>
            <div className="mt-4 px-2.5 py-1 bg-red-500/20 text-red-400 border border-red-500/30 rounded text-[10px] font-mono">
              Sensory Hijack: Emotional Outrage
            </div>
          </div>
        );

      case 'npc_streamer':
        return (
          <div className="absolute inset-0 bg-gradient-to-b from-purple-950 via-slate-900 to-rose-950 flex flex-col items-center justify-center p-4 select-none">
            <div className="relative">
              <div className="text-7xl animate-pulse">🍦</div>
              <div className="absolute -top-4 -right-6 bg-pink-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow animate-bounce">
                ICE CREAM!
              </div>
              <div className="absolute -bottom-3 -left-6 bg-amber-500 text-black text-[9px] font-bold px-1.5 py-0.5 rounded shadow">
                GANG GANG!
              </div>
            </div>
            <div className="mt-6 px-3 py-1.5 bg-black/70 rounded-lg border border-pink-500/30 text-center max-w-[220px]">
              <div className="text-xs font-bold text-pink-300">NPC Live Stream Loop</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Brain-Rot Score: 99% (Max Addiction)</div>
            </div>
          </div>
        );

      case 'ragebait_prank':
        return (
          <div className="absolute inset-0 bg-gradient-to-b from-red-950 via-slate-950 to-orange-950 flex flex-col items-center justify-center p-4 select-none">
            <div className="text-7xl animate-bounce mb-3">😱</div>
            <div className="px-3 py-1.5 bg-black/60 rounded-lg border border-red-500/30 text-center max-w-[210px]">
              <div className="text-xs font-bold text-red-400">PRANK: RENT TRIPLED 💀</div>
              <div className="text-[10px] text-slate-300 mt-0.5">Staged Conflict · Zero Value</div>
            </div>
          </div>
        );

      case 'python_tutorial':
        return (
          <div className="absolute inset-0 bg-slate-950 flex flex-col justify-center p-4 select-none">
            <div className="rounded-lg border border-emerald-500/30 bg-slate-900/90 p-3 font-mono text-[11px] space-y-2 shadow-lg">
              <div className="flex items-center justify-between text-[10px] text-emerald-400/80 border-b border-slate-800 pb-1">
                <span>python_optimization.py</span>
                <span>EDUCATIONAL</span>
              </div>
              <div className="text-slate-400"># Before (Slow 4-lines)</div>
              <div className="text-rose-400 line-through">res = []</div>
              <div className="text-slate-400"># After (List Comp)</div>
              <div className="text-emerald-400 font-bold">
                [x * 2 for x in nums if x % 2 == 0]
              </div>
            </div>
            <div className="mt-3 text-center text-[10px] text-emerald-400 font-mono bg-emerald-950/40 p-1.5 rounded border border-emerald-500/20">
              High Value Content · Brain-Rot: 12%
            </div>
          </div>
        );

      default:
        return (
          <div className="absolute inset-0 bg-slate-900 flex items-center justify-center">
            <Play className="w-12 h-12 text-slate-600" />
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Outer Phone Case Hardware */}
      <div className="relative w-[340px] h-[670px] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-4 border-slate-700/80 ring-1 ring-white/10 select-none">
        {/* Physical volume and power buttons representation */}
        <div className="absolute -left-[7px] top-24 w-[3px] h-9 bg-slate-600 rounded-l" />
        <div className="absolute -left-[7px] top-36 w-[3px] h-9 bg-slate-600 rounded-l" />
        <div className="absolute -right-[7px] top-28 w-[3px] h-12 bg-slate-600 rounded-r" />

        {/* Screen Bezel and Inner Display */}
        <div className="relative w-full h-full bg-black rounded-[36px] overflow-hidden flex flex-col border border-slate-800">
          
          {/* Top Dynamic Island & Status Bar */}
          <div className="absolute top-0 inset-x-0 z-30 pt-2 px-5 flex items-center justify-between text-white text-[11px] font-semibold tracking-tight">
            <span>09:41</span>
            
            {/* Dynamic Island Pill */}
            <div className="h-5 w-24 bg-black rounded-full border border-slate-800 flex items-center justify-center px-2 gap-1.5 shadow-sm">
              <div className="w-2 h-2 rounded-full bg-slate-800" />
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Microphone / Camera Active" />
              <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />
            </div>

            <div className="flex items-center gap-1 text-[10px]">
              <span>5G</span>
              <span>87%</span>
            </div>
          </div>

          {/* Social Media App Top Header */}
          <div className="absolute top-8 inset-x-0 z-20 px-4 py-2 flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setActiveApp(activeApp === 'tiktok' ? 'reels' : 'tiktok')}
                className="text-[11px] font-bold tracking-wider px-2 py-0.5 rounded bg-black/40 backdrop-blur border border-white/10 uppercase"
              >
                {activeApp === 'tiktok' ? 'TikTok' : 'Reels'}
              </button>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold">
              <span className="text-white/60 hover:text-white cursor-pointer">Following</span>
              <span className="text-white border-b-2 border-white pb-0.5 cursor-pointer">For You</span>
            </div>

            <div className="w-6 flex justify-end">
              <Search className="w-4 h-4 text-white/80" />
            </div>
          </div>

          {/* Simulated Video Viewport */}
          <div className="relative flex-1 w-full h-full overflow-hidden">
            {renderSimulatedVideoGraphic()}

            {/* Simulated OCR Scanner HUD (shows background Accessibility & Vision analysis) */}
            {showScannerHud && !isHijacked && (
              <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-3 pt-14 pb-24">
                {/* Scanner Target Text Bounding Boxes */}
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/70 backdrop-blur border border-emerald-500/40 text-[9px] font-mono text-emerald-400">
                    <Scan className="w-3 h-3 animate-spin text-emerald-400" />
                    <span>ACCESSIBILITY OCR: ACTIVE</span>
                  </div>

                  {activeOcrStream.map((line, idx) => (
                    <div 
                      key={idx} 
                      className="inline-block px-1.5 py-0.5 bg-black/80 rounded border border-cyan-400/60 text-[9px] font-mono text-cyan-300 shadow-sm"
                    >
                      [OCR: {line}]
                    </div>
                  ))}
                </div>

                {/* Subtitle / Audio transcription stream */}
                <div className="p-2 rounded bg-black/80 backdrop-blur border border-amber-500/30 max-w-[240px]">
                  <div className="flex items-center gap-1 text-[9px] font-mono text-amber-400">
                    <Volume2 className="w-3 h-3" />
                    <span>AUDIO STREAM ANALYZER:</span>
                  </div>
                  <div className="text-[10px] text-slate-200 mt-0.5 line-clamp-2 italic">
                    &ldquo;{activeAudioTranscript}&rdquo;
                  </div>
                </div>
              </div>
            )}

            {/* Floating Dopamine Interceptor HUD Pill */}
            {!isHijacked && (
              <div className="absolute top-16 left-3 right-3 z-20">
                <div className={`p-2 rounded-xl backdrop-blur-md border text-xs shadow-lg transition-all ${
                  addictionStatus === 'HIGH_ADDICTION'
                    ? 'bg-red-950/80 border-red-500/40 text-red-200'
                    : addictionStatus === 'MILD_FATIGUE'
                    ? 'bg-amber-950/80 border-amber-500/40 text-amber-200'
                    : 'bg-slate-900/80 border-slate-700/60 text-slate-300'
                }`}>
                  <div className="flex items-center justify-between text-[11px] font-semibold">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      <span>{isRomanUrdu ? 'Brain-Rot Tracker' : 'Brain-Rot Analyzer'}</span>
                    </span>
                    <span className="font-mono text-[10px]">
                      {formatTime(consecutiveSeconds)} / {formatTime(thresholdSeconds)}
                    </span>
                  </div>

                  {/* Progress to 15m Interception */}
                  <div className="w-full bg-black/50 h-1.5 rounded-full mt-1.5 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        addictionStatus === 'HIGH_ADDICTION' ? 'bg-red-500' :
                        addictionStatus === 'MILD_FATIGUE' ? 'bg-amber-500' : 'bg-sky-400'
                      }`}
                      style={{ width: `${Math.min((consecutiveSeconds / thresholdSeconds) * 100, 100)}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                    <span>
                      {isRomanUrdu ? 'Score: ' : 'Addiction: '}
                      <strong className="text-white">{brainRotLevel}%</strong>
                    </span>
                    <span className="text-[9px] uppercase tracking-wider font-mono">
                      {addictionStatus === 'HIGH_ADDICTION' ? '🚨 HIJACK TRIGGER' : 
                       addictionStatus === 'MILD_FATIGUE' ? '⚠️ WARNING' : 'HEALTHY'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Video Side Interaction Column */}
            <div className="absolute right-3 bottom-14 z-20 flex flex-col items-center gap-3 text-white">
              {/* Creator Avatar with follow badge */}
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-white flex items-center justify-center text-lg">
                  {currentVideo.creatorAvatar}
                </div>
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold text-white">
                  +
                </div>
              </div>

              {/* Like Button */}
              <button onClick={handleLike} className="flex flex-col items-center group">
                <div className={`p-2 rounded-full backdrop-blur-sm transition-transform active:scale-125 ${
                  isLiked ? 'text-red-500' : 'text-white'
                }`}>
                  <Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} />
                </div>
                <span className="text-[10px] font-bold">{currentVideo.likes}</span>
              </button>

              {/* Comment Button */}
              <div className="flex flex-col items-center">
                <div className="p-2 text-white">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold">{currentVideo.comments}</span>
              </div>

              {/* Share Button */}
              <div className="flex flex-col items-center">
                <div className="p-2 text-white">
                  <Share2 className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold">{currentVideo.shares}</span>
              </div>

              {/* Rotating Sound Disk */}
              <div className="w-8 h-8 rounded-full bg-slate-900 border-2 border-slate-700 flex items-center justify-center animate-spin duration-3000">
                <div className="w-3 h-3 rounded-full bg-slate-500" />
              </div>
            </div>

            {/* Video Bottom Metadata (Creator, Caption, Sound) */}
            <div className="absolute left-3 right-14 bottom-4 z-20 text-white space-y-1">
              <div className="font-bold text-xs">{currentVideo.creator}</div>
              <p className="text-[11px] text-slate-200 line-clamp-2 leading-snug">
                {currentVideo.caption}
              </p>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-300">
                <Music className="w-3 h-3 animate-pulse" />
                <span className="truncate">{currentVideo.soundName}</span>
              </div>
            </div>

            {/* THE INTERCEPTION OVERLAY (Mounted on Top when Hijacked) */}
            {isHijacked && <InterceptorOverlayUI />}
          </div>

          {/* Bottom Virtual Home Indicator Bar */}
          <div className="absolute bottom-1 inset-x-0 z-40 flex justify-center py-1">
            <div className="w-28 h-1 bg-white/40 rounded-full" />
          </div>
        </div>
      </div>

      {/* Simulator Control Dock Beneath Phone */}
      <div className="mt-4 flex flex-col items-center gap-2 max-w-[340px] w-full">
        {/* Next / Previous video swipe simulation */}
        <div className="flex items-center gap-2 w-full">
          <button
            onClick={prevVideo}
            disabled={isHijacked}
            className="flex-1 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center justify-center gap-1 transition-colors disabled:opacity-40"
          >
            <ChevronUp className="w-4 h-4" />
            <span>{isRomanUrdu ? 'Upar Scroll (Pichli)' : 'Swipe Up (Prev)'}</span>
          </button>

          <button
            onClick={nextVideo}
            disabled={isHijacked}
            className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white flex items-center justify-center gap-1 transition-colors disabled:opacity-40 shadow-sm"
          >
            <span>{isRomanUrdu ? 'Neechay Scroll (Agli)' : 'Swipe Down (Next)'}</span>
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Toolbar */}
        <div className="flex items-center justify-between w-full text-[11px] text-slate-400 px-1">
          <button 
            onClick={() => setShowScannerHud(!showScannerHud)}
            className="flex items-center gap-1 hover:text-slate-200 transition-colors"
          >
            {showScannerHud ? <EyeOff className="w-3.5 h-3.5 text-cyan-400" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{showScannerHud ? 'Scanner HUD: ON' : 'Scanner HUD: OFF'}</span>
          </button>

          <button
            onClick={triggerManualHijack}
            className="flex items-center gap-1 text-red-400 hover:text-red-300 font-medium transition-colors"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{isRomanUrdu ? 'Dopamine Hijack Test' : 'Test Hijack Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
