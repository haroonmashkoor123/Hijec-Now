import React, { useState } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  Lock, 
  Unlock, 
  Volume2, 
  Code2, 
  BookOpen, 
  Cpu, 
  HeartHandshake, 
  Sparkles,
  ArrowRight,
  LogOut,
  RefreshCw,
  Eye
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';
import { sound } from '../utils/soundEffects';

export const InterceptorOverlayUI: React.FC = () => {
  const { 
    currentChallenge, 
    challengeProgressSec, 
    isLessonCompleted,
    selectedOption, 
    quizOutcome, 
    submitAnswer, 
    canDismiss, 
    solveChallengeAndDismiss,
    strictLockMode,
    language 
  } = useDopamine();

  const [activeTab, setActiveTab] = useState<'lesson' | 'quiz'>('lesson');
  const [breathingPhase, setBreathingPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');

  const { microLesson, quiz, track, trackLabel, topic, difficulty } = currentChallenge;

  // Icon selector based on track
  const getTrackIcon = () => {
    switch (track) {
      case 'leetcode':
        return <Code2 className="w-5 h-5 text-amber-400" />;
      case 'english_vocab':
        return <BookOpen className="w-5 h-5 text-sky-400" />;
      case 'system_design':
        return <Cpu className="w-5 h-5 text-emerald-400" />;
      case 'mindfulness':
        return <HeartHandshake className="w-5 h-5 text-purple-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-indigo-400" />;
    }
  };

  const isRomanUrdu = language === 'roman_urdu';

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-slate-950/95 backdrop-blur-md text-white overflow-hidden animate-in fade-in zoom-in-95 duration-200">
      {/* System Hijack Top Banner */}
      <div className="bg-red-950/80 border-b border-red-500/30 px-3 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-red-500/20 text-red-400">
            <ShieldAlert className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-bold tracking-wider text-red-300 uppercase flex items-center gap-1.5">
              <span>{isRomanUrdu ? 'Dopamine Interception Shuru' : 'Dopamine Interception Active'}</span>
              <span className="text-[10px] text-red-400/80 font-normal">·</span>
              <span className="text-[10px] text-red-400/80 font-normal">
                {isRomanUrdu ? '15 min Zero-Value Block' : 'Brain-Rot Hijack'}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 line-clamp-1">
              {isRomanUrdu 
                ? 'Aap lagatar 15 minute se brain-rot dekh rahe thay. Screen lock ho chuki hai.' 
                : '15 min continuous zero-value scrolling detected. Feed intercepted.'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] font-mono text-slate-300">
          {canDismiss ? (
            <Unlock className="w-3 h-3 text-emerald-400" />
          ) : (
            <Lock className="w-3 h-3 text-amber-400" />
          )}
          <span>{canDismiss ? (isRomanUrdu ? 'Unlocked' : 'Unlocked') : (isRomanUrdu ? 'Locked' : 'Locked')}</span>
        </div>
      </div>

      {/* Progress Bar for 30s Micro-Lesson */}
      <div className="w-full bg-slate-800 h-1 relative">
        <div 
          className="h-full bg-gradient-to-r from-amber-500 via-sky-500 to-emerald-500 transition-all duration-300"
          style={{ width: `${(challengeProgressSec / 30) * 100}%` }}
        />
      </div>

      {/* Navigation Pill Tabs between Micro-Lesson and Quiz */}
      <div className="px-3 pt-2 pb-1.5 flex items-center justify-between border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          {getTrackIcon()}
          <div>
            <div className="text-xs font-semibold text-slate-200 line-clamp-1">{trackLabel}</div>
            <div className="text-[10px] text-slate-400">{topic} · {difficulty}</div>
          </div>
        </div>

        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('lesson')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              activeTab === 'lesson' 
                ? 'bg-slate-800 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isRomanUrdu ? '1. 30s Sabak' : '1. 30s Lesson'}
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'quiz' 
                ? 'bg-indigo-600 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{isRomanUrdu ? '2. Quiz Hal Karein' : '2. Unlock Quiz'}</span>
            {quizOutcome === 'correct' && <CheckCircle2 className="w-3 h-3 text-emerald-300" />}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3">
        {activeTab === 'lesson' ? (
          <div className="space-y-3">
            {/* Lesson Title & Timer */}
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">{microLesson.title}</h3>
                <p className="text-[11px] text-slate-400 mt-0.5">{currentChallenge.summary}</p>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-mono text-amber-400 bg-amber-950/40 border border-amber-500/20 px-2 py-0.5 rounded">
                <span>{30 - challengeProgressSec}s</span>
              </div>
            </div>

            {/* Vocab interactive word pronunciation */}
            {microLesson.vocabData && (
              <div className="p-3 rounded-lg bg-sky-950/30 border border-sky-500/20 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-bold text-sky-200">{microLesson.vocabData.word}</span>
                    <span className="text-xs font-mono text-sky-400">{microLesson.vocabData.pronunciation}</span>
                    <span className="text-[10px] text-slate-400 italic">({microLesson.vocabData.partOfSpeech})</span>
                  </div>
                  <button 
                    onClick={() => sound.speakWord(microLesson.vocabData!.word)}
                    className="p-1.5 rounded-md bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 transition-colors"
                    title="Pronounce word"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs text-slate-200 leading-relaxed">
                  <span className="font-semibold text-sky-300">{isRomanUrdu ? 'Matlab: ' : 'Definition: '}</span>
                  {microLesson.vocabData.definition}
                </div>
                <div className="text-[11px] text-slate-300 italic bg-slate-900/60 p-2 rounded border border-slate-800">
                  &ldquo;{microLesson.vocabData.example}&rdquo;
                </div>
                <div className="text-[11px] text-amber-300/90 flex items-center gap-1.5 pt-1">
                  <span className="font-semibold">{isRomanUrdu ? 'Yaad rakhne ka tareeqa (Mnemonic):' : 'Memory Trick:'}</span>
                  <span className="text-slate-300">{microLesson.vocabData.mnemonic}</span>
                </div>
              </div>
            )}

            {/* Code Snippet for LeetCode */}
            {microLesson.codeSnippet && (
              <div className="rounded-lg overflow-hidden border border-slate-800 bg-slate-950">
                <div className="bg-slate-900 px-3 py-1.5 text-[10px] font-mono text-slate-400 flex items-center justify-between border-b border-slate-800">
                  <span>leetcode_solution.py</span>
                  <span className="text-amber-400">O(N) Linear Time</span>
                </div>
                <pre className="p-3 text-[11px] font-mono text-emerald-400/95 overflow-x-auto leading-relaxed">
                  {microLesson.codeSnippet}
                </pre>
              </div>
            )}

            {/* System Design Architecture flow */}
            {microLesson.architectureFlow && (
              <div className="space-y-1.5">
                <div className="text-[11px] font-semibold text-slate-300">
                  {isRomanUrdu ? 'Data Flow aur Architecture:' : 'System Architecture Flow:'}
                </div>
                <div className="space-y-1">
                  {microLesson.architectureFlow.map((step, idx) => (
                    <div key={idx} className="p-2 rounded bg-slate-900/80 border border-slate-800 text-[10px] flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-sky-400">{step.source}</span>
                        <ArrowRight className="w-3 h-3 text-slate-500" />
                        <span className="font-semibold text-emerald-400">{step.destination}</span>
                      </div>
                      <span className="text-slate-400">{step.note}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Key Bullet Points */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-semibold text-slate-300">
                {isRomanUrdu ? 'Zaroori Asbaaq:' : 'Core Key Concepts:'}
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {microLesson.keyPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-mono text-[11px] mt-0.5">0{idx + 1}.</span>
                    <span className="leading-snug">{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ready to unlock button */}
            <div className="pt-2">
              <button
                onClick={() => setActiveTab('quiz')}
                className="w-full py-2.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-colors shadow-sm"
              >
                <span>{isRomanUrdu ? 'Agle Marhale Par Jayein (Quiz Hal Karein)' : 'Proceed to Unlock Quiz'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Quiz Question Card */}
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
              <div className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider font-semibold">
                {isRomanUrdu ? 'Screen Unlocking Sawal' : 'Unlocking Assessment'}
              </div>
              <p className="text-xs font-semibold text-white leading-relaxed">
                {quiz.question}
              </p>
              {quiz.codeSnippet && (
                <pre className="p-2 bg-slate-950 rounded border border-slate-800 text-[10px] font-mono text-amber-300/90 overflow-x-auto">
                  {quiz.codeSnippet}
                </pre>
              )}
            </div>

            {/* Quiz Options */}
            <div className="space-y-2">
              {quiz.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = idx === quiz.correctIndex;
                let btnStyle = 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-700';

                if (quizOutcome !== 'idle' && isSelected) {
                  btnStyle = isCorrect 
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200' 
                    : 'bg-red-950/60 border-red-500 text-red-200';
                } else if (quizOutcome === 'correct' && isCorrect) {
                  btnStyle = 'bg-emerald-950/40 border-emerald-500 text-emerald-200';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => submitAnswer(idx)}
                    disabled={quizOutcome === 'correct'}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all flex items-start gap-2.5 ${btnStyle}`}
                  >
                    <span className="w-5 h-5 rounded-full flex items-center justify-center bg-slate-800 text-[10px] font-mono shrink-0 mt-0.5">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="flex-1 leading-snug">{opt}</span>
                    {quizOutcome !== 'idle' && isSelected && (
                      <span className="shrink-0 mt-0.5">
                        {isCorrect ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-400" />
                        )}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Quiz Outcome feedback */}
            {quizOutcome === 'correct' && (
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs space-y-1 animate-in fade-in">
                <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isRomanUrdu ? 'Shaabash! Bilkul Sahi Jawab!' : 'Brilliant! Correct Answer!'}</span>
                </div>
                <p className="text-[11px] text-emerald-300/80 leading-relaxed">
                  {quiz.explanation}
                </p>
                <div className="text-[10px] font-mono text-emerald-400 pt-1">
                  +15 Focus Points · Brain-Rot Timer Reset
                </div>
              </div>
            )}

            {quizOutcome === 'wrong' && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-500/30 text-red-200 text-xs space-y-1 animate-in fade-in">
                <div className="font-bold flex items-center gap-1.5 text-red-300">
                  <XCircle className="w-4 h-4" />
                  <span>{isRomanUrdu ? 'Ghalat Jawab! Dobara Koshish Karein.' : 'Incorrect! Re-read lesson and retry.'}</span>
                </div>
                <p className="text-[11px] text-red-300/80">
                  {isRomanUrdu 
                    ? 'System tab tak unlock nahi hoga jab tak aap sahi jawab nahi dhoondh letay.' 
                    : 'The screen overlay remains locked until the correct answer is submitted.'}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Hijack Dismissal & Circuit-Breaker Action Bar */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span>{isRomanUrdu ? 'System Status:' : 'Interception Status:'}</span>
          <span className={canDismiss ? 'text-emerald-400 font-medium' : 'text-amber-400 font-medium'}>
            {canDismiss 
              ? (isRomanUrdu ? 'Screen Unlock Ho Gayi Hai' : 'Overlay Unlocked') 
              : (strictLockMode 
                  ? (isRomanUrdu ? 'Quiz hal kiye baghair exit mana hai' : 'Quiz required to exit')
                  : `${30 - challengeProgressSec}s required`
                )}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* Option A: Return to feed with timer reset */}
          <button
            onClick={() => solveChallengeAndDismiss(false)}
            disabled={!canDismiss}
            className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              canDismiss
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer'
                : 'bg-slate-900 text-slate-600 border border-slate-800/60 cursor-not-allowed'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isRomanUrdu ? 'Dobara Scroll Karein' : 'Resume Mindful Scroll'}</span>
          </button>

          {/* Option B: Exit TikTok/Instagram into deep work mode */}
          <button
            onClick={() => solveChallengeAndDismiss(true)}
            disabled={!canDismiss}
            className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              canDismiss
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow-sm'
                : 'bg-slate-900 text-slate-600 border border-slate-800/60 cursor-not-allowed'
            }`}
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isRomanUrdu ? 'App Band Karein (+50 XP)' : 'Close App (Deep Work)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
