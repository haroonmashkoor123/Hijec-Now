import React, { useState } from 'react';
import { 
  Target, 
  Code2, 
  BookOpen, 
  Cpu, 
  HeartHandshake, 
  Sparkles, 
  Plus, 
  Check, 
  HelpCircle,
  Smartphone,
  Scan,
  Brain,
  ShieldAlert
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';
import { GoalTrack } from '../types';
import { GOAL_CHALLENGES } from '../data/challenges';

export const GoalPreferencesPanel: React.FC = () => {
  const { 
    selectedTracks, 
    toggleTrack, 
    language,
    setShowPermissionModal 
  } = useDopamine();

  const [activeTab, setActiveTab] = useState<'tracks' | 'architecture' | 'custom'>('tracks');
  const [customQuestion, setCustomQuestion] = useState('');
  const [customTrack, setCustomTrack] = useState<GoalTrack>('leetcode');
  const [customOptions, setCustomOptions] = useState(['', '', '', '']);
  const [customCorrect, setCustomCorrect] = useState(0);
  const [customSavedMessage, setCustomSavedMessage] = useState(false);

  const isRomanUrdu = language === 'roman_urdu';

  const tracksConfig: { id: GoalTrack; label: string; desc: string; icon: React.ReactNode; color: string }[] = [
    {
      id: 'leetcode',
      label: 'LeetCode & Coding Algorithms',
      desc: isRomanUrdu ? 'Two Sum, Binary Search, O(n) Time Complexity, Data Structures' : 'Arrays, Two Pointers, Trees, Hash Maps, Time Complexities',
      icon: <Code2 className="w-4 h-4 text-amber-400" />,
      color: 'border-amber-500/30'
    },
    {
      id: 'english_vocab',
      label: 'English & IELTS Vocabulary',
      desc: isRomanUrdu ? 'IELTS Band 8+ Vocabulary, Pronunciation, Mnemonics aur Sentences' : 'Academic Band 8+ words, pronunciation, mnemonics & real collocations',
      icon: <BookOpen className="w-4 h-4 text-sky-400" />,
      color: 'border-sky-500/30'
    },
    {
      id: 'system_design',
      label: 'System Design & Tech Bytes',
      desc: isRomanUrdu ? 'Redis Caching, SQL vs NoSQL, Load Balancers, Scalability' : 'Cache-Aside, Microservices, Sharding, Message Queues',
      icon: <Cpu className="w-4 h-4 text-emerald-400" />,
      color: 'border-emerald-500/30'
    },
    {
      id: 'mindfulness',
      label: 'Cognitive Reset & Habit Loop',
      desc: isRomanUrdu ? 'Physiological Sigh, 20-20-20 Rule, Dopamine Re-sensitization' : 'Autonomic reset, breathing protocols, dopamine circuit breakers',
      icon: <HeartHandshake className="w-4 h-4 text-purple-400" />,
      color: 'border-purple-500/30'
    }
  ];

  const handleSaveCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestion.trim() || customOptions.some(o => !o.trim())) return;

    // Add to pool
    GOAL_CHALLENGES.unshift({
      id: `custom-${Date.now()}`,
      track: customTrack,
      trackLabel: customTrack === 'leetcode' ? 'LeetCode' : customTrack === 'english_vocab' ? 'Vocabulary' : 'Tech',
      topic: 'User Custom Target',
      difficulty: 'Medium',
      summary: customQuestion,
      microLesson: {
        title: customQuestion,
        keyPoints: [
          'Review the options carefully before submitting.',
          'Focus on memory recall to cement the concept.',
          'Self-directed learning provides 4x higher retention.'
        ]
      },
      quiz: {
        question: customQuestion,
        options: customOptions,
        correctIndex: customCorrect,
        explanation: 'Custom question verified by user!'
      }
    });

    setCustomSavedMessage(true);
    setTimeout(() => setCustomSavedMessage(false), 3000);
    setCustomQuestion('');
    setCustomOptions(['', '', '', '']);
  };

  return (
    <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm space-y-4">
      {/* Header and Sub Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
            <Target className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-wide">
              {isRomanUrdu ? 'Real-Life Goals & Architecture' : 'Goal Objectives & Core Architecture'}
            </h3>
            <p className="text-[10px] text-slate-400">
              {isRomanUrdu ? 'Hijacking par kaunsi informative videos aur quizes aayengi' : 'Targeted replacement topics & system design'}
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('tracks')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              activeTab === 'tracks'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isRomanUrdu ? 'Goals Intekhab' : 'Selected Tracks'}
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              activeTab === 'architecture'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isRomanUrdu ? 'Core Logic (4 Marhalay)' : 'Core Logic (4 Pillars)'}
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
              activeTab === 'custom'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isRomanUrdu ? '+ Naya Goal' : '+ Add Custom Goal'}
          </button>
        </div>
      </div>

      {/* Tab 1: Goal Tracks Selection */}
      {activeTab === 'tracks' && (
        <div className="space-y-2.5">
          <p className="text-[11px] text-slate-400 leading-snug">
            {isRomanUrdu 
              ? 'Jab 15 minute zero-value scrolling detect hogi, to in select kiye huway subjects ki 30s interactive video chalegi:' 
              : 'When 15 minutes of zero-value scrolling is detected, challenges from selected tracks will hijack the feed:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {tracksConfig.map(track => {
              const isSelected = selectedTracks.includes(track.id);

              return (
                <div
                  key={track.id}
                  onClick={() => toggleTrack(track.id)}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-start gap-3 select-none ${
                    isSelected
                      ? 'bg-slate-950/80 border-indigo-500/60 shadow-sm'
                      : 'bg-slate-950/30 border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                    {track.icon}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-slate-200 text-xs truncate">{track.label}</h4>
                      <div className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                        isSelected ? 'bg-indigo-600 text-white' : 'border border-slate-700'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {track.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Core Logic 4 Pillars Explainer (Exactly matches the user's prompt) */}
      {activeTab === 'architecture' && (
        <div className="space-y-3">
          <div className="p-3 rounded-lg bg-indigo-950/30 border border-indigo-500/20 text-xs text-indigo-200 leading-relaxed">
            {isRomanUrdu ? (
              <span>
                🧠 <strong>Core Logic (Yeh Kaam Kaise Karega?):</strong> Yeh app user ki app ko block nahi karegi (kyunke log blocking apps se irritated ho kar unhein delete kar dete hain). Yeh system background mein reh kar &ldquo;Smart Hijacking&rdquo; ya &ldquo;Dopamine Interruption&rdquo; ka concept use karega.
              </span>
            ) : (
              <span>
                🧠 <strong>Core Logic (Behavioral Interception):</strong> This app never hard-blocks or terminates apps. Instead, it runs seamlessly in the background as a &ldquo;Smart Hijack / Dopamine Circuit Breaker&rdquo; using four technical stages:
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Step 1 */}
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-sky-400 font-bold text-[11px]">
                <Smartphone className="w-4 h-4" />
                <span>1. Accessibility & Overlay Permission</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {isRomanUrdu
                  ? 'Mobile app user se screen overlay aur accessibility permission legi takay chalne wali app (TikTok/Reels) ka system-level data read kiya ja sake.'
                  : 'Requests AccessibilityService + SYSTEM_ALERT_WINDOW to read on-screen UI nodes and paint top-level overlays.'}
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-cyan-400 font-bold text-[11px]">
                <Scan className="w-4 h-4" />
                <span>2. Real-time Video Extraction</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {isRomanUrdu
                  ? 'Jab user screen scroll karega, to chalne wali video ke elements, subtitles aur audio stream ko background mein hamara light-weight model check karega.'
                  : 'On every vertical scroll gesture, background OCR & audio transcript nodes extract text to classify content genre.'}
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-[11px]">
                <Brain className="w-4 h-4" />
                <span>3. Brain-Rot Level Score</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {isRomanUrdu
                  ? 'Agar user lagatar 15 minute se "zero-value content" (gossip, random dance, funny videos) dekh raha hai, to counter "High Addiction" trigger kar dega.'
                  : 'Accumulates consecutive zero-value seconds. Exceeding 15 minutes of brain-rot elevates status to High Addiction.'}
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-red-400 font-bold text-[11px]">
                <ShieldAlert className="w-4 h-4" />
                <span>4. The Interception (Hijack)</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {isRomanUrdu
                  ? 'Agli video scroll hote hi, software TikTok ke upar Full-Screen Custom Overlay UI le aayega jo user ke goals (LeetCode, English, Coding) ki 30s interactive video chala dega. User tab tak aage nahi ja sakega jab tak quiz hal na kar le.'
                  : 'On next scroll, WindowManager launches the full-screen interactive micro-learning modal. Screen remains locked until the quiz is solved.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Custom Goal Creator */}
      {activeTab === 'custom' && (
        <form onSubmit={handleSaveCustom} className="space-y-3 text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">
              {isRomanUrdu ? 'Sawal ya Concept ka Naam:' : 'Question or Concept Topic:'}
            </label>
            <input
              type="text"
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              placeholder="e.g. In Python, what is the time complexity of dictionary lookup?"
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                {isRomanUrdu ? 'Goal Category:' : 'Track Category:'}
              </label>
              <select
                value={customTrack}
                onChange={(e) => setCustomTrack(e.target.value as GoalTrack)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs"
              >
                <option value="leetcode">LeetCode / Coding</option>
                <option value="english_vocab">English Vocabulary</option>
                <option value="system_design">System Design</option>
                <option value="mindfulness">Mindfulness</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                {isRomanUrdu ? 'Sahi Option (A/B/C/D):' : 'Correct Option:'}
              </label>
              <select
                value={customCorrect}
                onChange={(e) => setCustomCorrect(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs"
              >
                <option value={0}>Option A</option>
                <option value={1}>Option B</option>
                <option value={2}>Option C</option>
                <option value={3}>Option D</option>
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-[11px] font-semibold text-slate-300">
              {isRomanUrdu ? '4 Mumkina Jawab (Options):' : 'Quiz Options (A, B, C, D):'}
            </label>
            {customOptions.map((opt, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="w-5 text-center font-mono font-bold text-slate-400 text-[10px]">
                  {String.fromCharCode(65 + i)}
                </span>
                <input
                  type="text"
                  value={opt}
                  onChange={(e) => {
                    const next = [...customOptions];
                    next[i] = e.target.value;
                    setCustomOptions(next);
                  }}
                  placeholder={`Option ${String.fromCharCode(65 + i)}`}
                  className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            {customSavedMessage && (
              <span className="text-[11px] text-emerald-400 font-medium">
                {isRomanUrdu ? 'Naya Sawal Pool Mein Shamil Ho Gaya!' : 'Custom challenge added successfully!'}
              </span>
            )}
            <button
              type="submit"
              className="ml-auto px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>{isRomanUrdu ? 'Sawal Shamil Karein' : 'Save Challenge'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
