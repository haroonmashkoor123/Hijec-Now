import React from 'react';
import { 
  Activity, 
  Brain, 
  Zap, 
  Clock, 
  Sliders, 
  Target, 
  CheckCircle, 
  AlertCircle, 
  Sparkles, 
  ShieldCheck,
  ShieldAlert,
  Flame,
  Award
} from 'lucide-react';
import { useDopamine } from '../context/DopamineContext';

export const TelemetryPanel: React.FC = () => {
  const { 
    currentVideo, 
    consecutiveSeconds, 
    thresholdSeconds, 
    setThresholdSeconds, 
    brainRotLevel, 
    addictionStatus,
    activeOcrStream,
    activeAudioTranscript,
    activeContentClassification,
    fastForwardAddiction,
    triggerManualHijack,
    strictLockMode,
    setStrictLockMode,
    interceptionsCount,
    quizzesSolvedCount,
    minutesSaved,
    dopamineDetoxScore,
    language,
    permissions,
    setShowPermissionModal
  } = useDopamine();

  const isRomanUrdu = language === 'roman_urdu';

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4">
      {/* 1. Real-Time Screen Extraction & Classification Monitor */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white tracking-wide">
                {isRomanUrdu ? 'Real-Time Screen Video Extraction' : 'Screen Stream Extraction HUD'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {isRomanUrdu ? 'Accessibility Service + OCR + Audio Stream' : 'Background lightweight NLP & Computer Vision'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>STREAMING</span>
          </div>
        </div>

        {/* Video metadata inspected */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 uppercase font-mono">App Target</div>
            <div className="font-semibold text-slate-200 mt-0.5 flex items-center gap-1">
              <span>{currentVideo.app.toUpperCase()}</span>
              <span className="text-[10px] text-slate-400">({currentVideo.creator})</span>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Classification</div>
            <div className="font-semibold text-slate-200 mt-0.5 truncate">
              {currentVideo.valueLabel}
            </div>
          </div>
        </div>

        {/* Live Subtitles & OCR stream */}
        <div className="space-y-1.5 text-xs">
          <div className="text-[10px] font-mono text-slate-400 uppercase">
            {isRomanUrdu ? 'Live Subtitles & Extracted OCR:' : 'Extracted On-Screen Subtitles & OCR:'}
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-cyan-300 space-y-1">
            <div className="text-slate-400 text-[10px] italic">
              &ldquo;{activeAudioTranscript}&rdquo;
            </div>
            <div className="flex flex-wrap gap-1 pt-1">
              {activeOcrStream.map((tag, i) => (
                <span key={i} className="px-1.5 py-0.2 bg-slate-900 border border-cyan-500/30 rounded text-[9px]">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Brain-Rot Level Score & Addiction Trigger Counter */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-lg ${
              addictionStatus === 'HIGH_ADDICTION' ? 'bg-red-500/10 text-red-400' :
              addictionStatus === 'MILD_FATIGUE' ? 'bg-amber-500/10 text-amber-400' :
              'bg-sky-500/10 text-sky-400'
            }`}>
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white tracking-wide">
                {isRomanUrdu ? 'Brain-Rot Level Score' : 'Brain-Rot Addiction Score'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {isRomanUrdu ? '15 Minute Zero-Value Counter' : 'Continuous passive dopamine saturation index'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-base font-bold font-mono text-white">{brainRotLevel}%</span>
            <div className="text-[9px] text-slate-400 uppercase">
              {addictionStatus.replace('_', ' ')}
            </div>
          </div>
        </div>

        {/* Visual Score Gauge Bar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] text-slate-300">
            <span>{isRomanUrdu ? 'Dopamine Loop Timer:' : 'Passive Scroll Duration:'}</span>
            <span className="font-mono text-slate-200">
              {formatTime(consecutiveSeconds)} / {formatTime(thresholdSeconds)}
            </span>
          </div>

          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
            <div 
              className={`h-full transition-all duration-300 ${
                addictionStatus === 'HIGH_ADDICTION' 
                  ? 'bg-gradient-to-r from-amber-500 to-red-500' 
                  : addictionStatus === 'MILD_FATIGUE' 
                  ? 'bg-gradient-to-r from-sky-400 to-amber-500' 
                  : 'bg-sky-400'
              }`}
              style={{ width: `${Math.min((consecutiveSeconds / thresholdSeconds) * 100, 100)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[9px] text-slate-500 pt-0.5">
            <span>Safe (0-5m)</span>
            <span>Warning (5-10m)</span>
            <span className="text-red-400 font-semibold">High Addiction (15m+)</span>
          </div>
        </div>

        {/* Addiction Threshold Preset Switcher */}
        <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-300 font-medium flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>{isRomanUrdu ? 'Addiction Trigger Hadh:' : 'Trigger Threshold:'}</span>
            </span>
            <span className="font-mono text-indigo-300 font-semibold">
              {thresholdSeconds >= 60 ? `${thresholdSeconds / 60} min` : `${thresholdSeconds}s (Quick Demo)`}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1.5 text-xs">
            {[15, 30, 60, 900].map(sec => (
              <button
                key={sec}
                onClick={() => setThresholdSeconds(sec)}
                className={`py-1 rounded text-[10px] font-mono font-medium transition-colors border ${
                  thresholdSeconds === sec
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {sec === 900 ? '15 Min (Real)' : `${sec}s Demo`}
              </button>
            ))}
          </div>
        </div>

        {/* Action Trigger Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={fastForwardAddiction}
            className="py-2 px-3 rounded-lg bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-red-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Flame className="w-3.5 h-3.5 text-red-400" />
            <span>{isRomanUrdu ? '15 Min Simulate Karein' : 'Simulate 15m Rot'}</span>
          </button>

          <button
            onClick={triggerManualHijack}
            className="py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-indigo-200" />
            <span>{isRomanUrdu ? 'Dopamine Hijack Shuru' : 'Trigger Interception'}</span>
          </button>
        </div>
      </div>

      {/* 3. Real-life Impact & Interception Stats */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white tracking-wide">
                {isRomanUrdu ? 'Real-life Goal Tarakki' : 'Cognitive Retention & Impact'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {isRomanUrdu ? 'Dopamine Interception ke nataij' : 'Dopamine redirection performance'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Interceptions</div>
            <div className="text-lg font-bold font-mono text-indigo-400 mt-0.5">{interceptionsCount}</div>
            <div className="text-[9px] text-slate-500">Traps broken</div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Quizzes Solved</div>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">{quizzesSolvedCount}</div>
            <div className="text-[9px] text-slate-500">LeetCode/Vocab</div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Minutes Saved</div>
            <div className="text-lg font-bold font-mono text-amber-400 mt-0.5">{minutesSaved}m</div>
            <div className="text-[9px] text-slate-500">From doomscroll</div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Focus Score</div>
            <div className="text-lg font-bold font-mono text-sky-400 mt-0.5">{dopamineDetoxScore}</div>
            <div className="text-[9px] text-slate-500">XP Points</div>
          </div>
        </div>

        {/* Strict Lock Mode Toggle */}
        <div className="pt-1 flex items-center justify-between text-xs text-slate-300">
          <div>
            <div className="font-semibold text-slate-200">
              {isRomanUrdu ? 'Hard Intercept Lock (Strict Mode)' : 'Hard Intercept Lock'}
            </div>
            <div className="text-[10px] text-slate-400">
              {isRomanUrdu ? 'Quiz hal kiye baghair aage nahi jane dega' : 'Cannot scroll forward until quiz is solved'}
            </div>
          </div>

          <button
            onClick={() => setStrictLockMode(!strictLockMode)}
            className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
              strictLockMode ? 'bg-emerald-600' : 'bg-slate-700'
            }`}
          >
            <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
              strictLockMode ? 'translate-x-5' : 'translate-x-0'
            }`} />
          </button>
        </div>
      </div>
    </div>
  );
};
