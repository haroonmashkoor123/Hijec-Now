import { GoalChallenge } from '../types';

export const GOAL_CHALLENGES: GoalChallenge[] = [
  {
    id: 'ch-leetcode-twosum',
    track: 'leetcode',
    trackLabel: 'LeetCode & Algorithms',
    topic: 'Two Sum & Hash Map Lookup (O(N) Optimization)',
    difficulty: 'Easy',
    summary: 'Never use nested loops for Two Sum. Use a Hash Map to achieve linear O(n) time complexity.',
    microLesson: {
      title: 'Optimal Two Sum in 30 Seconds',
      keyPoints: [
        'A brute-force double loop checks every pair: O(n²) time complexity.',
        'Optimal approach: Store previously seen numbers and their indices in a Hash Map (Dictionary).',
        'For current number x, complement = target - x. Check if complement exists in the map.',
        'Lookup in a Hash Map takes O(1) average time, reducing overall runtime to O(n).'
      ],
      codeSnippet: `def twoSum(nums: list[int], target: int) -> list[int]:
    seen = {} # val -> index
    for i, num in enumerate(nums):
        diff = target - num
        if diff in seen:
            return [seen[diff], i]
        seen[num] = i
    return []`
    },
    quiz: {
      question: 'Given nums = [3, 2, 4] and target = 6, what does the Hash Map contain right before finding the matching pair?',
      codeSnippet: 'nums = [3, 2, 4], target = 6\ni=0: num=3, diff=3 (not in seen) -> seen[3]=0\ni=1: num=2, diff=4 (not in seen) -> seen[2]=1\ni=2: num=4, diff=2 -> ?',
      options: [
        '{3: 0, 2: 1} and target match 2 is found',
        '{3: 0, 4: 2} and match is 3',
        '{2: 1, 4: 2} with no match',
        'Empty dictionary {}'
      ],
      correctIndex: 0,
      explanation: 'At index 2 (num = 4), diff is 6 - 4 = 2. Since 2 is already in seen at index 1, the algorithm immediately returns [1, 2] with O(1) lookup!'
    }
  },
  {
    id: 'ch-leetcode-binarysearch',
    track: 'leetcode',
    trackLabel: 'LeetCode & Algorithms',
    topic: 'Binary Search: Preventing Integer Overflow',
    difficulty: 'Medium',
    summary: 'Calculating mid as (low + high) // 2 can overflow 32-bit integers in languages like C++, Java, or Go.',
    microLesson: {
      title: 'Binary Search Mid Calculation Bug',
      keyPoints: [
        'In sorted array searching, mid element divides search space in half.',
        'Common trap: (low + high) / 2 can overflow if low + high exceeds 2^31 - 1.',
        'Safe formula: mid = low + (high - low) // 2',
        'Bitwise alternative: mid = (low + high) >>> 1 (in Java/JS).'
      ],
      codeSnippet: `// ❌ Risky (Integer Overflow in 32-bit):
int mid = (low + high) / 2;

// ✅ Safe Standard:
int mid = low + (high - low) / 2;`
    },
    quiz: {
      question: 'Why is `low + (high - low) / 2` mathematically and computationally superior?',
      options: [
        'It prevents (low + high) from exceeding maximum integer limit while maintaining identical value',
        'It computes twice as fast on CPU registers',
        'It converts O(log N) to O(1) runtime',
        'It works on unsorted arrays without sorting'
      ],
      correctIndex: 0,
      explanation: 'Algebraically, low + (high - low)/2 = (2*low + high - low)/2 = (low + high)/2, but (high - low) never exceeds the positive limit, preventing 32-bit sign flip bugs.'
    }
  },
  {
    id: 'ch-vocab-ephemeral',
    track: 'english_vocab',
    trackLabel: 'English & IELTS Vocabulary',
    topic: 'Academic Word: Ephemeral (ɪˈfem.ər.əl)',
    difficulty: 'Medium',
    summary: 'Replace "short-lived" or "temporary" in IELTS essays and professional communication.',
    microLesson: {
      title: 'IELTS Band 8+ Vocabulary: Ephemeral',
      keyPoints: [
        'Meaning: Lasting for only a very short time; fleeting or transitory.',
        'Collocations: Ephemeral pleasure, ephemeral fame, ephemeral viral trends.',
        'Synonyms: Transitory, evanescent, fleeting, momentary.',
        'Antonyms: Perpetual, permanent, enduring.'
      ],
      vocabData: {
        word: 'Ephemeral',
        pronunciation: '/ɪˈfem.ər.əl/',
        partOfSpeech: 'Adjective',
        definition: 'Lasting for a very short time; brief and fleeting.',
        example: 'Social media trends provide ephemeral dopamine spikes, whereas mastering deep skills yields lasting fulfillment.',
        mnemonic: 'Think of "Elephant on a Ferris wheel"—it will last for a very short, ephemeral time before falling!'
      }
    },
    quiz: {
      question: 'Which of the following sentences uses "ephemeral" with correct semantic precision?',
      options: [
        'The ephemeral joy of mindless scrolling fades within seconds, leaving fatigue.',
        'He constructed an ephemeral steel bridge that endured 200 years.',
        'She felt an ephemeral love for her child that lasted throughout her life.',
        'The mountain has stood in an ephemeral state for geological eras.'
      ],
      correctIndex: 0,
      explanation: '"Ephemeral" means short-lived or transitory. Dopamine hits from short-form videos are literally ephemeral—spiking quickly and disappearing immediately.'
    }
  },
  {
    id: 'ch-vocab-pernicious',
    track: 'english_vocab',
    trackLabel: 'English & IELTS Vocabulary',
    topic: 'Academic Word: Pernicious (pəˈnɪʃ.əs)',
    difficulty: 'Hard',
    summary: 'Describing gradual, hidden, yet deadly or harmful effects.',
    microLesson: {
      title: 'Advanced Vocabulary: Pernicious',
      keyPoints: [
        'Meaning: Having a very harmful or destructive effect, especially in a gradual, sneaky way.',
        'Usage context: Pernicious influence of doomscrolling, pernicious effects of inflation.',
        'Synonyms: Insidious, deleterious, damaging, destructive.',
        'Antonyms: Beneficial, benign, salutary.'
      ],
      vocabData: {
        word: 'Pernicious',
        pronunciation: '/pəˈnɪʃ.əs/',
        partOfSpeech: 'Adjective',
        definition: 'Having a gradual, subtle, but extremely harmful or deadly effect.',
        example: 'Doomscrolling has a pernicious influence on cognitive stamina and sleep architecture.',
        mnemonic: 'Sounds like "Per-VICIOUS"—so vicious that it ruins you slowly without you noticing!'
      }
    },
    quiz: {
      question: 'What is the subtle difference between "harmful" and "pernicious"?',
      options: [
        'Pernicious causes harm subtly and gradually over time, often unseen until serious damage occurs',
        'Pernicious only applies to physical bacteria and biological toxins',
        'Pernicious means harmless or accidental',
        'Pernicious is used exclusively for positive economic developments'
      ],
      correctIndex: 0,
      explanation: 'Unlike blatant harm (e.g. breaking a bone), a pernicious habit (like hours of doomscrolling) works insidiously in the background, eroding your focus unnoticed.'
    }
  },
  {
    id: 'ch-system-design-cache',
    track: 'system_design',
    trackLabel: 'System Design & Architecture',
    topic: 'Cache Invalidation & Cache-Aside Pattern',
    difficulty: 'Medium',
    summary: 'The standard caching pattern used by Netflix, Twitter, and Uber to handle millions of QPS.',
    microLesson: {
      title: 'System Design: Cache-Aside (Lazy Loading)',
      keyPoints: [
        'Client requests data from Application Server.',
        'Server checks Redis Cache first (Cache Hit -> return in <2ms).',
        'On Cache Miss: Server queries SQL Database (50-200ms).',
        'Server writes retrieved data into Redis cache with a TTL (Time To Live), then returns to Client.',
        'On Data Update: Update SQL Database, then Invalidate (delete) cache key!'
      ],
      architectureFlow: [
        { source: 'Client App', destination: 'API Gateway', protocol: 'HTTPS/REST', note: 'Requesting User Profile' },
        { source: 'API Gateway', destination: 'Redis Cluster', protocol: 'In-Memory TCP', note: 'Check cache hit (sub-millisecond)' },
        { source: 'App Server', destination: 'Postgres DB', protocol: 'Connection Pool', note: 'Fallback query on cache miss' },
        { source: 'App Server', destination: 'Redis', protocol: 'SETEX (Key, TTL, Data)', note: 'Populate cache for future requests' }
      ]
    },
    quiz: {
      question: 'In the Cache-Aside pattern, what should you do when a user updates their profile in the database?',
      options: [
        'Delete (invalidate) the key in Redis so the next read fetches fresh data from DB',
        'Keep the old cache entry forever until the Redis server restarts',
        'Drop the entire database table',
        'Block all subsequent read requests until midnight'
      ],
      correctIndex: 0,
      explanation: 'Deleting the cached key is safer than updating it immediately, as it avoids concurrency race conditions between competing write threads.'
    }
  },
  {
    id: 'ch-mindfulness-reset',
    track: 'mindfulness',
    trackLabel: 'Cognitive Reset & Habit Loop',
    topic: 'The 20-20-20 Rule & Dopamine Reset Protocol',
    difficulty: 'Easy',
    summary: 'Break the hyper-stimulus dopamine loop with bilateral eye saccades and autonomic nervous system regulation.',
    microLesson: {
      title: 'Autonomic Reset: The Physiological Sigh',
      keyPoints: [
        'Doomscrolling triggers shallow breathing, raising cortisol and keeping you in a trance.',
        'Stanford Neurobiology (Dr. Andrew Huberman): Two quick inhales through the nose, followed by one long, slow exhale through the mouth.',
        'Repeat 2-3 times to pop open collapsed alveoli in the lungs and instantly drop heart rate.',
        'Look at something at least 20 feet away to relax the ciliary muscles of the eyes.'
      ]
    },
    quiz: {
      question: 'How does the "Physiological Sigh" (double inhale + extended slow exhale) chemically affect the nervous system?',
      options: [
        'It maximizes CO2 offloading and triggers parasympathetic vagus nerve activation to slow heart rate',
        'It elevates adrenaline to keep you scrolling faster',
        'It blocks oxygen from reaching the prefrontal cortex',
        'It shuts down memory formation'
      ],
      correctIndex: 0,
      explanation: 'The double inhale expands collapsed air sacs, and the prolonged exhale stimulates the vagus nerve, signaling the parasympathetic nervous system to slow heart rate and break compulsive loops.'
    }
  }
];
