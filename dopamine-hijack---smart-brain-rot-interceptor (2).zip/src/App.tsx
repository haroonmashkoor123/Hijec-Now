import React, { useState } from 'react';
import { DopamineProvider, useDopamine } from './context/DopamineContext';
import { Header } from './components/Header';
import { PhoneSimulator } from './components/PhoneSimulator';
import { TelemetryPanel } from './components/TelemetryPanel';
import { GoalPreferencesPanel } from './components/GoalPreferencesPanel';
import { PermissionsModal } from './components/PermissionsModal';
import { ArchitectureExplainerModal } from './components/ArchitectureExplainerModal';
import { 
  Sparkles, 
  Brain, 
  Flame, 
  ShieldAlert, 
  HelpCircle,
  Lightbulb,
  CheckCircle2
} from 'lucide-react';

const DashboardContent: React.FC = () => {
  const [showArchModal, setShowArchModal] = useState(false);
  const { language, triggerManualHijack, fastForwardAddiction } = useDopamine();

  const isRomanUrdu = language === 'roman_urdu';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      <Header onOpenArchitecture={() => setShowArchModal(true)} />

      {/* Main Workspace Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        
        {/* Top Context Notification / Value Proposition Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/60 border border-indigo-500/20 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 shrink-0 mt-0.5">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono font-bold uppercase tracking-wider text-indigo-300">
                {isRomanUrdu ? 'Dopamine Interruption Engine' : 'Cognitive Behavior Redirection Engine'}
              </div>
              <h2 className="text-sm sm:text-base font-bold text-white mt-0.5">
                {isRomanUrdu 
                  ? 'Social media ko block karne ke bajaye, 15 minute ke brain-rot ke baad full-screen goal overlay le aayen.' 
                  : 'Instead of futile blocking apps, replace passive dopamine with 30s micro-learning & interactive quizzes.'}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {isRomanUrdu 
                  ? 'Screen scroll par video ka OCR aur subtitles check honge. High addiction trigger hone par Agli video par LeetCode/English ka screen lock aa jayega.' 
                  : 'Inspects on-screen nodes via Accessibility. When 15m of zero-value scrolling accumulates, the next scroll locks the feed with goal challenges.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={fastForwardAddiction}
              className="py-2 px-3.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-red-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Flame className="w-4 h-4 text-red-400" />
              <span>{isRomanUrdu ? '15 Min Fast-Forward' : 'Simulate 15m Trap'}</span>
            </button>

            <button
              onClick={() => setShowArchModal(true)}
              className="py-2 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{isRomanUrdu ? 'Core Logic Dekhein' : 'System Logic (4 Steps)'}</span>
            </button>
          </div>
        </div>

        {/* Core Layout Grid: Phone Simulator on Left, Control Center on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Phone Simulator */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full flex items-center justify-between px-2 mb-3 text-xs text-slate-400">
              <span className="font-semibold text-slate-300">
                {isRomanUrdu ? 'Mobile App Live Simulator' : 'Target App Active Window'}
              </span>
              <span className="text-[11px] font-mono text-indigo-400">
                TikTok / Instagram Reels
              </span>
            </div>

            <PhoneSimulator />
          </div>

          {/* Right Column: Telemetry & Goals Configuration Panels */}
          <div className="lg:col-span-7 space-y-5">
            <TelemetryPanel />
            <GoalPreferencesPanel />
          </div>
        </div>
      </main>

      {/* Modals */}
      <PermissionsModal />
      <ArchitectureExplainerModal 
        isOpen={showArchModal} 
        onClose={() => setShowArchModal(false)} 
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 px-4 py-4 text-center text-xs text-slate-500">
        <p>
          Dopamine Hijack Architecture · Android Accessibility Service & System Alert Window (Overlay) Simulation
        </p>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <DopamineProvider>
      <DashboardContent />
    </DopamineProvider>
  );
}
